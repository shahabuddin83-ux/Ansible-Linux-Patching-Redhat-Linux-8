# RHEL Server Patching Automation – Ansible

Production-grade Ansible automation for patching Red Hat Enterprise Linux
servers (RHEL 7, 8, 9) with wave-based rollout, pre/post health checks,
rollback support, and HTML reporting.

---

## Directory Structure

```
rhel_patching/
├── ansible.cfg                          # Ansible configuration
├── inventory/
│   └── hosts.ini                        # Host inventory (waves)
├── group_vars/
│   ├── dev.yml                          # Dev-environment overrides
│   └── production.yml                   # Production-environment overrides
├── playbooks/
│   ├── patch_all_waves.yml              # Wave-based full patching
│   ├── patch_security.yml               # Security-only / emergency patches
│   ├── patch_dryrun.yml                 # Dry run – check without applying
│   └── patch_rollback.yml               # Rollback using dnf history
└── roles/
    └── rhel_patching/
        ├── defaults/main.yml            # All configurable variables
        ├── tasks/
        │   ├── main.yml                 # Orchestrator
        │   ├── preflight.yml            # Pre-flight checks
        │   ├── pre_patch.yml            # Snapshots, package lists
        │   ├── patch.yml                # Core dnf update + reboot
        │   ├── post_patch.yml           # Post-patch validation
        │   └── report.yml               # Report generation
        ├── handlers/main.yml            # Reboot handler
        ├── templates/
        │   ├── patch_report.txt.j2      # Text report template
        │   └── patch_report.html.j2     # HTML report template
        └── meta/main.yml                # Role metadata
```

---

## Quick Start

### 1. Configure Inventory

Edit `inventory/hosts.ini` with your RHEL server hostnames:

```ini
[dev]
dev-server-01.example.com

[production]
prod-server-01.example.com
prod-server-02.example.com
```

### 2. Configure SSH Access

```bash
# Generate SSH key for Ansible
ssh-keygen -t rsa -b 4096 -f ~/.ssh/ansible_rsa -N ""

# Copy to each target host
ssh-copy-id -i ~/.ssh/ansible_rsa.pub ansible@prod-server-01.example.com

# Verify connectivity
ansible all -i inventory/hosts.ini -m ping
```

### 3. Dry Run First (Recommended)

```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_dryrun.yml
```

### 4. Apply Patches

```bash
# All waves (dev → staging → production)
ansible-playbook -i inventory/hosts.ini playbooks/patch_all_waves.yml

# Security patches only
ansible-playbook -i inventory/hosts.ini playbooks/patch_security.yml

# Target specific hosts only
ansible-playbook -i inventory/hosts.ini playbooks/patch_security.yml \
  -l prod-server-01.example.com
```

---

## Common Usage Patterns

### Check what would be patched (no changes)
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_dryrun.yml
```

### Patch only development servers
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_all_waves.yml \
  --limit wave1
```

### Patch with specific advisory IDs (CVE targeting)
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_security.yml \
  -e "patch_update_type=minimal" \
  -e '{"patch_advisory_ids":["RHSA-2024:1234","RHSA-2024:5678"]}'
```

### Run only pre-flight checks
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_all_waves.yml \
  --tags preflight
```

### Skip reboot (apply patches without rebooting)
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_security.yml \
  -e "patch_reboot_on_kernel=false" \
  -e "patch_always_reboot=false"
```

### Rollback last patch transaction
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_rollback.yml \
  -l prod-server-01.example.com
```

### Rollback to specific dnf transaction ID
```bash
ansible-playbook -i inventory/hosts.ini playbooks/patch_rollback.yml \
  -l prod-server-01.example.com \
  -e "rollback_transaction_id=42"
```

---

## Key Variables (defaults/main.yml)

| Variable | Default | Description |
|---|---|---|
| `patch_update_type` | `security` | `security`, `bugfix`, `all`, `minimal` |
| `patch_update_kernel` | `true` | Whether to update kernel packages |
| `patch_reboot_on_kernel` | `true` | Reboot if new kernel installed |
| `patch_always_reboot` | `false` | Always reboot after patching |
| `patch_enforce_window` | `false` | Enforce maintenance window |
| `patch_window_start_hour` | `2` | Maintenance window start (24h) |
| `patch_window_end_hour` | `6` | Maintenance window end (24h) |
| `patch_exclude_packages` | `[]` | Packages to exclude from update |
| `patch_download_only` | `false` | Download only, don't install |
| `patch_enable_rollback` | `true` | Save package lists for rollback |
| `patch_notify_slack` | `false` | Enable Slack notifications |
| `patch_notify_email` | `false` | Enable email notifications |

---

## Patch Workflow

```
Pre-flight checks
  ├── OS version check (RHEL only)
  ├── Maintenance window check
  ├── Disk space check (>15% free required)
  ├── DNF lock check
  └── Repository connectivity

Pre-patch tasks
  ├── Save package list (rollback reference)
  ├── Save running services list
  ├── Check available updates
  └── Send start notification

Core patching (dnf update)
  ├── Apply updates (security / all / bugfix / advisory)
  ├── Detect kernel update
  └── Reboot if required

Post-patch validation
  ├── Verify critical services running
  ├── Check for failed systemd units
  ├── Compare services before/after
  ├── Check disk and memory health
  ├── Check remaining pending updates
  └── Send completion notification

Report generation
  ├── Text report (saved on host + fetched locally)
  └── HTML report (saved on host + fetched locally)
```

---

## Prerequisites

- Ansible 2.12+
- Python 3.6+ on target hosts
- `ansible` user with passwordless sudo on targets
- DNF / RHEL subscription active on targets
- Optional: `sysstat` package for disk I/O stats

---

## Logs and Reports

All logs are saved on each target host under `/var/log/ansible_patching/`:

| File | Description |
|---|---|
| `patch_YYYY-MM-DD.log` | Main execution log |
| `packages_before_*.txt` | Package list before patching |
| `packages_after_*.txt` | Package list after patching |
| `package_changes_*.txt` | Diff of changed packages |
| `services_before_*.txt` | Services before patching |
| `services_after_*.txt` | Services after patching |
| `reports/patch_report_<host>_<date>.txt` | Text report |
| `reports/patch_report_<host>_<date>.html` | HTML report |

Reports are also fetched to `./reports/<hostname>/` on the Ansible controller.
